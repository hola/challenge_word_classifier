# lz-string-csharp
C# Implementation of the [lz-string javascript library](http://pieroxy.net/blog/pages/lz-string/index.html)

After the other [lz-string implementation](https://github.com/jawa-the-hutt/lz-string-csharp) returned different results in compressToBase64, I decided to reimplement the newest version of the lz-string library. This isn't optimized or extensively tested, but it seems to work just fine.
